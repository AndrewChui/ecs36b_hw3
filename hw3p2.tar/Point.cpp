//represents a point in the x-y plane. 
//Point objects can be added and subtracted, and the square of the
//norm of a point can be calculated
#include "Point.h"

//operator+
Point Point::operator+(const Point& rhs)const{
    Point final;
    final.x = x + rhs.x;
    final.y = y + rhs.y;
    return final;
}
//operator-
Point Point::operator-(const Point& rhs)const{
    Point final;
    final.x = x - rhs.x;
    final.y = y - rhs.y;
    return final;
}

//operator<<//print a point
std::ostream& operator<< (std::ostream& os, const Point& p)
{
    os << "(" << p.x << "," << p.y << ")";
    return os;
}

//operator>> read a point
std::istream& operator>>(std::istream& is, Point& p)
{
    is >> p.x >> p.y;
    return is;
}