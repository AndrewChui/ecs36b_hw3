#include <iostream>
#include "Domain.h"
using namespace std;

Domain::~Domain(void){};
Domain::Domain(void){
    sizex = 600;
    sizey = 500;
}
//add a SHAPE pointer to the vector of Shape pointers s
void Domain::addShape(const Shape* p){
    //  std::vector<const Shape*> s;
    s.push_back(p);
}

//checks whether all shapes fit into the Domain
//define a RECTANGLE object representing the domain and using the shapes' fits_in functions
//checks whether there are overlaps between shapes(using the Shapes' overlaps functions)
//determine the diagnostic message
//print the svg header
//the svg representation of all shapes
void Domain::draw(void){

     //define a rectangle object
    Rectangle domain(Point(0, 0), 600, 500);

    //check wheter all shapes fit into the domain
    bool all_fit = true;
    for(const Shape*shape : s){
        if(!shape -> fits_in(domain)){
            all_fit = false;
            break;
        }
    }

    //checks whether there are overlaps between shapes and using the shapes'fits_in functions
    bool overlap = false;
    for(int i = 0; i < s.size(); i++){
        // for(int j = 0; j < s.size(); j++){
         for(int j = i+1; j < s.size(); j++){
            //make sure to not compare twice
            // if(i == j){
            //     continue;
            // }
            if(s[i]->overlaps(*s[j])){
                overlap = true;
                break;
            }
        }
    }
    //determine the diagnostic message
    // determine diagnostic message
    std::string message;
    if (!all_fit) {
        message = "does not fit";
    }
    else if (overlap) {
        message = "overlap";
    }
    else {
        message = "ok";
    }

    //print the svg header
    std::cout << "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"700\" height=\"600\">" << std::endl;
    std::cout << "<g transform=\"matrix(1,0,0,-1,50,550)\" fill=\"white\" fill-opacity=\"0.5\" stroke=\"black\" stroke-width=\"2\">" << std::endl;
    std::cout << "<rect fill=\"lightgrey\" x=\"0\" y=\"0\" width=\"600\" height=\"500\"></rect>" << std::endl;

    //print svg representation of all shapes
    for (size_t i = 0; i < s.size(); i++) {
    const Shape* shape = s[i];   
    if (const Rectangle* r = dynamic_cast<const Rectangle*>(shape)) {
        r->draw();
    } else if (const Circle* c = dynamic_cast<const Circle*>(shape)) {
        c->draw();
    }
}
    std::cout << "</g>" << std::endl;

    // Print diagnostic message

    std::cout << "<g transform=\"matrix(1,0,0,1,50,590)\" font-family=\"Arial\" font-size=\"32\">" << std::endl;
    std::cout << "<text x=\"0\" y=\"0\">" << message << "</text>" << std::endl;
    std::cout << "</g>" << std::endl;

    // Close SVG
    std::cout << "</svg>" << std::endl;

}


