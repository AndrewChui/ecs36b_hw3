//Every shape must define:
//how to draw itself in SVG
//How to check if it fits in the domain rectangle

//How to check if it overlaps:
//-rectagle-rectangle
//circle-circle
//circle-rectangle

#include <iostream>
#include "Shape.h"
//rectangle destructor
Rectangle::~Rectangle(){}

//double dispatch
bool Rectangle::overlaps(const Shape& s)const{
    if(typeid(s) == typeid(Rectangle)){
        const Rectangle temp = static_cast<const Rectangle&>(s);
        return overlaps(temp);
    }
    if(typeid(s) == typeid(Circle)){
        const Circle temp = (const Circle&)s;
        return overlaps(temp);
    }
    return false;
}

//rectangle-rectangle collision; rectangle vs rectangle
//one is completely left: x1 + w1 <= x2
//one is completely right: x2 + w2 <= x1
//one is completely below: y1 + h1 <= y2
//one is completely above: y2 + h2 <= y1
//otherwisw they overlap
bool Rectangle::overlaps(const Rectangle& r)const{//test1.in
    //rectangle A is completely to the left of rectangle B
    //rectangle A's x position + rectagle A's width <= rectangle B's x position.
    if((position.x + width) <= r.position.x){
        return false;
    }
    //rectangle A is completely to the right of rectangle B
    //opposite of above, rectangle B's x position + rectagle B's width <= rectangle A's x position.
    if((r.position.x + r.width) <= position.x){
        return false;
    }
    //rectangle A is completely below rectangle B
    //rectangle's A's y position + rectangle A's height <= rectangle B's y position
    if((position.y + height) <= r.position.y){
        return false;
    }

    //rectangle A is completely above rectangle B
    //rectangle's B's y position + rectangle B's height <= rectangle A's y position
    if((r.position.y + r.height) <= position.y){
        return false;
    }
    return true;
}

//rectangle-circle collision; rectangle vs circle
// checking if the circle is completely ourside the rectangle 
bool Rectangle::overlaps(const Circle& r)const{//test1.in
    // //1. The range; the boundary of the rectangle

    // //x coordinates of the rectangle's left edge
    // int left = position.x;

    // //x coordinate of the rectangle's right edge
    // int right = position.x + width;

    // //y- coordinate of the rectangle's bottom edge
    // int bottom = position.y; 

    // //y coordinate of the rectangle's top edge
    // int top = position.y + height;

    // //checking if the rightmost side of the circle is left of the leftmost side of the rectangle 
    // if(r.center.x + r.radius < left){ //circle is completely left of the rectangle
    //     return false;
    // }
    // //checking if the leftmost side of the circle is right of the rightmost side of the rectangle
    // if(r.center.x - r.radius > right){//circle is completely right of the rectangle
    //     return false;
    // }

    // //checking if the topmost side of the circle is below the bottommost side of the rectangle
    // if(r.center.y + r.radius < bottom){//circle is completely below rectangle
    //     return false;
    // }

    // //checking if the bottommost side of the circle is above the topmost side of the rectangle
    // if(r.center.y - r.radius > top){//circle is completely above rectangle 
    //     return false;
    // }
    
    // //otherwise circle overlaps rectangle
    // return true;
    

    //call the same function Circle::overlaps(const Rectangle& r) const
    return r.overlaps(*this);
}

//fits_in() -> check if rectangle is fully inside domain rectangle
bool Rectangle::fits_in(const Rectangle& r)const {//test1.in
    //we need to check that all 4 points of the smaller rectangles are within the larger rectangle
    //x positions
    if(position.x >= r.position.x && (position.x + width) <= (r.position.x + r.width)){
        //y positions
        if(position.y >= r.position.y && (position.y + height) <= (r.position.y + r.height)){
            return true;
        }
        return false;
    }
    return false;

}

//svg output
void Rectangle::draw(void) const {
    std::cout << "<rect x=\"" << position.x
              << "\" y=\"" << position.y
              << "\" width=\"" << width
              << "\" height=\"" << height
              << "\" />\n";
}


//circle class

//circle destructor
Circle::~Circle(){};

//double dispatch
bool Circle::overlaps(const Shape& s) const{
    if(typeid(s) == typeid(Rectangle)){
        const Rectangle temp = static_cast<const Rectangle&>(s);
        return overlaps(temp);
    }
    if(typeid(s) == typeid(Circle)){
        const Circle temp = (const Circle&)s;
        return overlaps(temp);
    }
    return false;
}

bool Circle::overlaps(const Circle& r)const{
    // if((center.x + radius) <= (r.center.x - r.radius)){
    //     return false;
    // }
    // if((center.x - radius) >= (r.center.x + r.radius)){
    //     return false;
    // }

    // if((center.y + radius) <= (r.center.y - r.radius)){
    //     return false;
    // }

    // if((center.y - radius) >= (r.center.y + r.radius)){
    //     return false;
    // }
    // return true;
    ///////won't work

    double distance = (center.x - r.center.x) * (center.x - r.center.x) + (center.y - r.center.y) * (center.y - r.center.y);
    if(distance < (radius + r.radius) * (radius + r.radius)){
        return true;
    }
    else
    {
        return false;
    }
}

bool Circle::overlaps(const Rectangle& r)const{
    //1. Compute closest point
    //compute the coordinates of the point of the rectangle
    // that is closest to t
    int xn = std::min(std::max(center.x, r.position.x), r.position.x + r.width);
    int yn = std::min(std::max(center.y, r.position.y), r.position.y + r.height);
    //2. Compute distance squared
    //compute the distance d between the point (xn and xy)
    int distance_x = center.x - xn;
    int distance_y = center.y - yn;
    //3. Compare with radius^2
    if(distance_x*distance_x + distance_y*distance_y < radius * radius){
        return true;
    }
    else{return false;}
}

bool Circle::fits_in(const Rectangle& r)const{
    //check if the circle is fully inside the rectangle
    bool right_Inside = (center.x + radius) <= (r.position.x + r.width);
    bool left_Inside = (center.x - radius) >= r.position.x;
    bool top_Inside = (center.y + radius) <= (r.position.y + r.height);
    bool bottom_Inside = (center.y - radius) >= (r.position.y);
    if(right_Inside && left_Inside && top_Inside && bottom_Inside){
        return true;
    }
    else{return false;}
}

void Circle::draw(void)const{
    std::cout << "<circle cx=\"" << center.x
              << "\" cy=\"" << center.y
              << "\" r=\"" << radius
              << "\" />\n";
}



